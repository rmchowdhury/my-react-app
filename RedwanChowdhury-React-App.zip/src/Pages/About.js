import React from 'react';

const About = () => {
  return <div>This is the About Page</div>;
};

export default About;