import React from 'react';

const Services = () => {
  return <div>Services Page</div>;
};

export default Services;